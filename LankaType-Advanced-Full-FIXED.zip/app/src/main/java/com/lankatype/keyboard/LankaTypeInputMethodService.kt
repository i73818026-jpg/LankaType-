package com.lankatype.keyboard
import android.content.*
import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.view.*
import android.widget.*
import kotlin.math.max

class LankaTypeInputMethodService:InputMethodService(){
 private var shift=false
 private var dark=true
 private var sinhala=false
 private val prefs by lazy{getSharedPreferences("settings",MODE_PRIVATE)}
 override fun onCreate(){super.onCreate();dark=prefs.getBoolean("dark",true)}
 override fun onCreateInputView():View{
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(5,5,5,5);setBackgroundColor(if(dark)Color.rgb(24,24,28) else Color.rgb(245,245,245))}
  val tools=LinearLayout(this)
  listOf("⚙","😊","📋","🎙","Aa","🌐").forEach{t->addTool(tools,t){when(t){"⚙"->startActivity(Intent(this,SettingsActivity::class.java));"😊"->commit("😊");"📋"->paste();"Aa"->{shift=!shift;refresh()};"🌐"->{sinhala=!sinhala;refresh()}}}}
  root.addView(tools,LinearLayout.LayoutParams(-1,50))
  val sug=LinearLayout(this);listOf("හායි","හරි","ස්තූතියි","ඔයා","මම","අද").forEach{w->addKey(sug,w,1f){commit(w)}};root.addView(sug,LinearLayout.LayoutParams(-1,45))
  root.addView(row("1234567890"));root.addView(row("QWERTYUIOP"));root.addView(row("ASDFGHJKL"));root.addView(row("ZXCVBNM"))
  val bottom=LinearLayout(this)
  addKey(bottom,"⇧",1f){shift=!shift;refresh()};addKey(bottom,"⌫",1f){currentInputConnection?.deleteSurroundingText(1,0)}
  addKey(bottom,",",.8f){commit(",")};addKey(bottom,"SPACE",3f){commit(" ")};addKey(bottom,".",.8f){commit(".")}
  addKey(bottom,"↵",1.2f){currentInputConnection?.commitText("\n",1)}
  root.addView(bottom,LinearLayout.LayoutParams(-1,58));return root
 }
 private fun row(chars:String)=LinearLayout(this).apply{chars.forEach{c->addKey(this,c.toString(),1f){val s=if(shift)c.uppercaseChar().toString() else c.lowercaseChar().toString();commit(if(sinhala)translit(s)else s)}}}
 private fun translit(s:String)=mapOf("mama" to "මම","api" to "අපි","oya" to "ඔයා","hari" to "හරි")[s]?:s
 private fun addKey(p:LinearLayout,t:String,w:Float,a:()->Unit){val b=button(t);b.setOnClickListener{a()};p.addView(b,LinearLayout.LayoutParams(0,max(48,prefs.getInt("keyHeight",52)),w))}
 private fun addTool(p:LinearLayout,t:String,a:()->Unit){val b=button(t);b.textSize=18f;b.setOnClickListener{a()};p.addView(b,LinearLayout.LayoutParams(0,50,1f))}
 private fun button(t:String)=Button(this).apply{text=t;textSize=14f;isAllCaps=false;setTextColor(if(dark)Color.WHITE else Color.BLACK);setBackgroundColor(if(dark)Color.rgb(58,58,65) else Color.WHITE);setPadding(2,2,2,2)}
 private fun commit(s:String){currentInputConnection?.commitText(s,1)}
 private fun paste(){val cm=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager;cm.primaryClip?.takeIf{it.itemCount>0}?.let{commit(it.getItemAt(0).coerceToText(this).toString())}}
 private fun refresh(){inputView=onCreateInputView()}
}