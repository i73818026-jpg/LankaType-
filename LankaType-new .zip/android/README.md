# LankaType - Android APK Build & Installation Guide
Commands:
$ cd android
$ ./gradlew assembleDebug
$ adb install -r app/build/outputs/apk/debug/app-debug.apk