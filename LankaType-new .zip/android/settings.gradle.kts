rootProject.name = "LankaType"
include(":app")