package com.lankatype.keyboard

import com.lankatype.keyboard.engine.SinhalaTransliterationEngine
import org.junit.Assert.assertEquals
import org.junit.Test

class SinhalaTransliterationTest {
    @Test
    fun testCorePromptExamples() {
        assertEquals("මම", SinhalaTransliterationEngine.transliterate("mama"))
        assertEquals("අපි", SinhalaTransliterationEngine.transliterate("api"))
        assertEquals("ඔයාට", SinhalaTransliterationEngine.transliterate("oyata"))
        assertEquals("කොහොමද", SinhalaTransliterationEngine.transliterate("kohomada"))
        assertEquals("ගෙදර", SinhalaTransliterationEngine.transliterate("gedara"))
        assertEquals("යනවා", SinhalaTransliterationEngine.transliterate("yanawa"))
    }
}