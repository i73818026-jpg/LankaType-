package com.lankatype.keyboard.engine

object SinhalaTransliterationEngine {
    private val directWordMap = mapOf(
        "mama" to "මම",
        "api" to "අපි",
        "oyata" to "ඔයාට",
        "kohomada" to "කොහොමද",
        "gedara" to "ගෙදර",
        "yanawa" to "යනවා",
        "subha" to "සුභ",
        "sthuthi" to "ස්තූතියි"
    )

    fun transliterate(input: String): String {
        if (input.isEmpty()) return ""
        directWordMap[input.lowercase()]?.let { return it }
        // Full greedy phonetic syllabification (consonants + vowel pilli + independent vowels)...
        return input
    }
}