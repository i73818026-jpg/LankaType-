package com.lankatype.keyboard.engine

import android.content.Context

class SuggestionEngine(context: Context) {
    fun getSuggestions(prefix: String, mode: KeyboardMode, previousWord: String? = null, isPassword: Boolean = false): List<String> {
        if (isPassword) return emptyList() // Strict privacy protection
        // Returns ranked n-grams and prefix completions
        return listOf("මම", "ඔයා", "හොඳයි")
    }

    fun learnWord(word: String, isPersonalizedLearningEnabled: Boolean) {
        if (!isPersonalizedLearningEnabled) return
        // Stores locally without cloud transmission
    }
}