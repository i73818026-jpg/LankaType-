# LankaType v1.0.0

A privacy-first Sinhala/English Android keyboard project.

## Build
Open this folder as an Android Gradle project in Android Studio or AndroidIDE.

The included GitHub Actions workflow can build a debug APK in the cloud.
