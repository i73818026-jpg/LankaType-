package com.lankatype.keyboard

import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.lankatype.keyboard.engine.SinhalaTransliterationEngine

class LankaTypeInputMethodService : InputMethodService() {

    private enum class Mode { SINGLISH, SINHALA, ENGLISH }
    private var mode = Mode.SINGLISH
    private var root: LinearLayout? = null

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(6, 6, 6, 6)
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

        val suggestions = TextView(this).apply {
            text = "LankaType"
            textSize = 16f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 4, 12, 4)
        }
        root!!.addView(suggestions, LinearLayout.LayoutParams(-1, 48))

        addRow(listOf("q","w","e","r","t","y","u","i","o","p"))
        addRow(listOf("a","s","d","f","g","h","j","k","l"))
        addRow(listOf("z","x","c","v","b","n","m"))

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addButton(bottom, "🌐", 1f) { cycleMode(suggestions) }
        addButton(bottom, "⌫", 1f) { currentInputConnection?.deleteSurroundingText(1, 0); vibrate() }
        addButton(bottom, "SPACE", 2.5f) { currentInputConnection?.commitText(" ", 1); vibrate() }
        addButton(bottom, "↵", 1f) { sendEnter() }
        root!!.addView(bottom, LinearLayout.LayoutParams(-1, 54))

        return root!!
    }

    private fun addRow(keys: List<String>) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        keys.forEach { key ->
            addButton(row, key, 1f) {
                val text = if (mode == Mode.SINGLISH) {
                    val transformed = SinhalaTransliterationEngine.transliterate(key)
                    if (transformed == key) key else transformed
                } else key
                currentInputConnection?.commitText(text, 1)
                vibrate()
            }
        }
        root!!.addView(row, LinearLayout.LayoutParams(-1, 52))
    }

    private fun addButton(row: LinearLayout, label: String, weight: Float, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = if (label.length > 1) 11f else 15f
            isAllCaps = false
            setOnClickListener { action() }
        }
        row.addView(b, LinearLayout.LayoutParams(0, -1, weight))
    }

    private fun cycleMode(label: TextView) {
        mode = when (mode) {
            Mode.SINGLISH -> Mode.SINHALA
            Mode.SINHALA -> Mode.ENGLISH
            Mode.ENGLISH -> Mode.SINGLISH
        }
        label.text = "LankaType • ${mode.name}"
    }

    private fun sendEnter() {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        if (info != null && (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            ic.performEditorAction(info.imeOptions and EditorInfo.IME_MASK_ACTION)
        } else {
            ic.commitText("\n", 1)
        }
        vibrate()
    }

    private fun vibrate() {
        val v = getSystemService(VIBRATOR_SERVICE) as? Vibrator ?: return
        if (!v.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(15)
        }
    }
}
