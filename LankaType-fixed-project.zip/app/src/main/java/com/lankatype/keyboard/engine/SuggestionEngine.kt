package com.lankatype.keyboard.engine

import android.content.Context

class SuggestionEngine(context: Context) {
    fun getSuggestions(
        prefix: String,
        previousWord: String? = null,
        isPassword: Boolean = false
    ): List<String> {
        if (isPassword) return emptyList()
        val words = listOf("මම", "ඔයා", "හොඳයි", "හරි", "ස්තූතියි", "දැන්")
        return words.filter { prefix.isBlank() || it.startsWith(prefix) }.take(3)
    }
}
