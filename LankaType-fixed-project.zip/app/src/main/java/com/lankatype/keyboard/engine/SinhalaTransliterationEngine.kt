package com.lankatype.keyboard.engine

object SinhalaTransliterationEngine {
    private val directWordMap = mapOf(
        "mama" to "මම",
        "api" to "අපි",
        "oyata" to "ඔයාට",
        "kohomada" to "කොහොමද",
        "gedara" to "ගෙදර",
        "yanawa" to "යනවා",
        "subha" to "සුභ",
        "sthuthi" to "ස්තූතියි",
        "hari" to "හරි",
        "hondai" to "හොඳයි",
        "oyaa" to "ඔයා",
        "mata" to "මට",
        "dan" to "දැන්",
        "mokakda" to "මොකක්ද",
        "kauda" to "කවුද",
        "meeka" to "මේක",
        "eka" to "එක"
    )

    fun transliterate(input: String): String {
        if (input.isEmpty()) return ""
        directWordMap[input.lowercase()]?.let { return it }

        // Small fallback for common Singlish syllables.
        var s = input.lowercase()
        val replacements = listOf(
            "th" to "ත්", "dh" to "ද්", "kh" to "ඛ", "gh" to "ඝ",
            "ch" to "ච", "sh" to "ශ",
            "aa" to "ා", "ae" to "ැ", "ee" to "ී", "ii" to "ී",
            "oo" to "ූ", "uu" to "ූ",
            "a" to "අ", "i" to "ඉ", "u" to "උ", "e" to "එ", "o" to "ඔ"
        )
        // Only use the fallback when it is likely a single syllable; otherwise
        // leave unknown words intact rather than producing misleading Sinhala.
        if (s.length <= 4) {
            for ((from, to) in replacements) s = s.replace(from, to)
            return s
        }
        return input
    }
}
