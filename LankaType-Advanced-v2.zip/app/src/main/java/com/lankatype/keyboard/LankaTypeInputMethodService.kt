package com.lankatype.keyboard
import android.content.*; import android.graphics.Color; import android.inputmethodservice.InputMethodService; import android.view.*; import android.widget.*

class LankaTypeInputMethodService:InputMethodService(){
 lateinit var root:LinearLayout; lateinit var board:LinearLayout
 var caps=false; var sinhala=false
 val bg=Color.rgb(18,18,20); val key=Color.rgb(38,38,42); val white=Color.WHITE; val accent=Color.rgb(255,193,7)
 override fun onCreateInputView():View{ build(); return root }
 fun build(){
  root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setBackgroundColor(bg); root.setPadding(5,5,5,7)
  val top=LinearLayout(this); top.gravity=Gravity.CENTER_VERTICAL
  listOf("⌘","😊","📋","🎙","Aa","🌐").forEach{ addTool(top,it) }
  root.addView(top,LinearLayout.LayoutParams(-1,48))
  val sug=LinearLayout(this); sug.gravity=Gravity.CENTER
  listOf("හායි","හරි","ස්තූතියි","ඔයා","මම","අද").forEach{ t-> val v=TextView(this); v.text=t; v.textSize=15f; v.setTextColor(white); v.gravity=17; v.setPadding(18,0,18,0); v.setOnClickListener{commit(t)}; sug.addView(v) }
  root.addView(sug,LinearLayout.LayoutParams(-1,42))
  board=LinearLayout(this); board.orientation=LinearLayout.VERTICAL; root.addView(board,LinearLayout.LayoutParams(-1,0,1f)); redraw()
 }
 fun addTool(r:LinearLayout,s:String){val v=TextView(this);v.text=s;v.textSize=20f;v.setTextColor(white);v.gravity=17;v.setOnClickListener{when(s){"😊"->commit("😊");"📋"->paste(); "Aa"->{caps=!caps;redraw()};"🌐"->{sinhala=!sinhala;redraw()};else->Toast.makeText(this,"Tool: $s",0).show()}};r.addView(v,LinearLayout.LayoutParams(0,-1,1f))}
 fun redraw(){board.removeAllViews(); row(listOf("1","2","3","4","5","6","7","8","9","0")); row(listOf("Q","W","E","R","T","Y","U","I","O","P")); row(listOf("A","S","D","F","G","H","J","K","L")); row(listOf("⇧","Z","X","C","V","B","N","M","⌫")); val r=LinearLayout(this); button(r,"123",1.2f){};button(r,"😊",1f){commit("😊")};button(r,"🌐",1f){sinhala=!sinhala;redraw()};button(r,"space",4f){commit(" ")};button(r,".",1f){commit(".")};button(r,"↵",1.3f){sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_ENTER))};board.addView(r,LinearLayout.LayoutParams(-1,0,1f))}
 fun row(a:List<String>){val r=LinearLayout(this);a.forEach{s->button(r,s,1f){if(s=="⌫")currentInputConnection.deleteSurroundingText(1,0) else if(s=="⇧"){caps=!caps;redraw()} else commit(if(caps)s.uppercase() else s.lowercase())}};board.addView(r,LinearLayout.LayoutParams(-1,0,1f))}
 fun button(r:LinearLayout,s:String,w:Float,fn:()->Unit){val b=Button(this);b.text=s;b.textSize=15f;b.setTextColor(white);b.setBackgroundColor(if(s=="↵")accent else key);b.isAllCaps=false;b.setOnClickListener{fn()};r.addView(b,LinearLayout.LayoutParams(0,-1,w).apply{setMargins(2,2,2,2)})}
 fun commit(s:String){currentInputConnection?.commitText(s,1)}
 fun paste(){val c=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager;c.primaryClip?.let{if(it.itemCount>0)commit(it.getItemAt(0).coerceToText(this).toString())}}
}
