package com.lankatype.keyboard.engine
object SinhalaTransliterationEngine {
 private val m=mapOf("mama" to "මම","api" to "අපි","oya" to "ඔයා","oyata" to "ඔයාට","hari" to "හරි","kohomada" to "කොහොමද","sthuthi" to "ස්තූතියි")
 fun transliterate(s:String)=m[s.trim().lowercase()]?:s
}
