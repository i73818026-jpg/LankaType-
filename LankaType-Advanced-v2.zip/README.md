LankaType Advanced v2.0.0 - QWERTY, number row, suggestions, emoji, clipboard, language/caps controls, toolbar and offline Sinhala dictionary.
